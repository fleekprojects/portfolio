<?php 
define('CLIENT_URL', 'http://portfolioz.tk/p/3'); 
?>