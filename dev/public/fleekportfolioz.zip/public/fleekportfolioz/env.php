<?php 
define('CLIENT_URL', 'http://dev.portfolioz.tk/1'); 
?>