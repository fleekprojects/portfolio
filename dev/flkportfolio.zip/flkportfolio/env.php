<?php 
define('CLIENT_URL', 'https://dev.portfolioz.tk/p/3'); 
?>