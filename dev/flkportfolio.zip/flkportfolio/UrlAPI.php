<?php
class UrlAPI {
    protected $apiUrl = CLIENT_URL;
}
?>